package com.mdq.auditinspectionapp.ViewModel;

public class QCResultRequestBaseViewModel {


}
