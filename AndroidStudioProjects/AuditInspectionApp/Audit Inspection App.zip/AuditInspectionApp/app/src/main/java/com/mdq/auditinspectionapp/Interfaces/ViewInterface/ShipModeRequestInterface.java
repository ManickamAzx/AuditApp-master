package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface ShipModeRequestInterface {

    void generateShipModeRequest();
}
