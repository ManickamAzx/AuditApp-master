package com.mdq.auditinspectionapp.ViewModel;

public class UpdateProductionBaseViewModel {

    public String foreCastDelDate;
    public String remarks;
    public int dispatchModeId;
    public String updateForm;
    public String sourceFlag;
    public int sourceId;
    public String pgmCode;
    public String sysOrderNo;
    public int styleId;
    public String custOrderNo;

    public String getForeCastDelDate() {
        return foreCastDelDate;
    }

    public void setForeCastDelDate(String foreCastDelDate) {
        this.foreCastDelDate = foreCastDelDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public int getDispatchModeId() {
        return dispatchModeId;
    }

    public void setDispatchModeId(int dispatchModeId) {
        this.dispatchModeId = dispatchModeId;
    }

    public String getUpdateForm() {
        return updateForm;
    }

    public void setUpdateForm(String updateForm) {
        this.updateForm = updateForm;
    }

    public String getSourceFlag() {
        return sourceFlag;
    }

    public void setSourceFlag(String sourceFlag) {
        this.sourceFlag = sourceFlag;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getPgmCode() {
        return pgmCode;
    }

    public void setPgmCode(String pgmCode) {
        this.pgmCode = pgmCode;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public int getStyleId() {
        return styleId;
    }

    public void setStyleId(int styleId) {
        this.styleId = styleId;
    }

    public String getCustOrderNo() {
        return custOrderNo;
    }

    public void setCustOrderNo(String custOrderNo) {
        this.custOrderNo = custOrderNo;
    }
}
