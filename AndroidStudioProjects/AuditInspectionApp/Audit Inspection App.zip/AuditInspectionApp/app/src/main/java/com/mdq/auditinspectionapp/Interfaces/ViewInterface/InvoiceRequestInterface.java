package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface InvoiceRequestInterface {
    void generateInvoiceRequest();
}
