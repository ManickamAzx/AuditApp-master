package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateSeasonRequestModel {
    public String Authorization;
}
