package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface FinalInvoiceRequestInterface {

    void generateFinalVoiceRequest();

}
