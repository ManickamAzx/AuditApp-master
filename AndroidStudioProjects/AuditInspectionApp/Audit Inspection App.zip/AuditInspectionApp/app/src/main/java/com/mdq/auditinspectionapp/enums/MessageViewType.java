package com.mdq.auditinspectionapp.enums;


public enum MessageViewType {
    InView,
    Dialog,
    Toast,
    SnackBar,
}


