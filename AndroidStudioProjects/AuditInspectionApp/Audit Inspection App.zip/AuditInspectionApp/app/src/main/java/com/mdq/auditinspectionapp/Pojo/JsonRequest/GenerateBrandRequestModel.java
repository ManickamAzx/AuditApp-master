package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateBrandRequestModel {

    public String sourceId;
    public String sourceFlag;
    public String seasonId;


}
