package com.mdq.auditinspectionapp.ViewModel;

public class SeasonRequestBaseViewModel {


    private String Authorization;

    public String getAuthorization() {
        return Authorization;
    }

    public void setAuthorization(String authorization) {
        Authorization = authorization;
    }

}
