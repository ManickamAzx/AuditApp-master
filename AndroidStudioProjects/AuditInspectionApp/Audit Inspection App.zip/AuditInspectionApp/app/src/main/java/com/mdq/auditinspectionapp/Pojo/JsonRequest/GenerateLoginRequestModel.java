package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateLoginRequestModel {
    public String emp_id;
    public String password;
}
