package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateQCNameRequestModel {

    public int dptid ;

}
