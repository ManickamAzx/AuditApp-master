package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface SourceRequestInterface {

    void generateSourceRequest();
}
