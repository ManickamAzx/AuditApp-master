package com.mdq.auditinspectionapp.ViewModel;

public class FinalInvoiceRequestBaseViewModel {

    private String piNo;
    private String sourceFlag;
    private Integer sourceId;
    private String from;
    private String to;
    private String orderStatus;

    public String getPiNo() {
        return piNo;
    }

    public void setPiNo(String piNo) {
        this.piNo = piNo;
    }

    public String getSourceFlag() {
        return sourceFlag;
    }

    public void setSourceFlag(String sourceFlag) {
        this.sourceFlag = sourceFlag;
    }

    public Integer getSourceId() {
        return sourceId;
    }

    public void setSourceId(Integer seasonId) {
        this.sourceId = seasonId;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}
