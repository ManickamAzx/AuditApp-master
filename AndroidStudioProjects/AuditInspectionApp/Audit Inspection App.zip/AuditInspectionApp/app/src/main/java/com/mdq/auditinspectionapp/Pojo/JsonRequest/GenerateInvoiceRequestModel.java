package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateInvoiceRequestModel {

    public String sourceId;
    public String supplierCode;
    public String sourceFlag;
    public String seasonId;
    public String brandId;
    public String from;
    public String to;

}
