package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface SupplierRequestInterface {
    void generateSupplierRequest();
}
