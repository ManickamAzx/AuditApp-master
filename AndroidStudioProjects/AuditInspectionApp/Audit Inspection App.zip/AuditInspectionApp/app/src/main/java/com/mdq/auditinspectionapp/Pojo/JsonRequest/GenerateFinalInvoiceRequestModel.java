package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateFinalInvoiceRequestModel {
    public String piNo;
    public String sourceFlag;
    public Integer sourceId;
    public String from;
    public String to;
    public String orderStatus;
}
