package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface UpdateInspectionRequestInterface {
    void generateUpdateInspectionRequest();

}
