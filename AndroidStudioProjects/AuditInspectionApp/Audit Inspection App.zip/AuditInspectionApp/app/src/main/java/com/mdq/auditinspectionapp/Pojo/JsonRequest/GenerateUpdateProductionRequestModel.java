package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateUpdateProductionRequestModel {


    public String foreCastDelDate;
    public String remarks;
    public int dispatchModeId;
    public String updateForm;
    public String sourceFlag;
    public int sourceId;
    public String pgmCode;
    public String sysOrderNo;
    public int styleId;
    public String custOrderNo;

}
