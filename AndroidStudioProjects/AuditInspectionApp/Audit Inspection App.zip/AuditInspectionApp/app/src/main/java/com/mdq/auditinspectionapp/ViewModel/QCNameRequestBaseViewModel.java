package com.mdq.auditinspectionapp.ViewModel;

public class QCNameRequestBaseViewModel {

    private int dptid;

    public int getDptid() {
        return dptid;
    }

    public void setDptid(int dptid) {
        this.dptid = dptid;
    }
}
