package com.mdq.auditinspectionapp.enums;

public class ViewType {
}
