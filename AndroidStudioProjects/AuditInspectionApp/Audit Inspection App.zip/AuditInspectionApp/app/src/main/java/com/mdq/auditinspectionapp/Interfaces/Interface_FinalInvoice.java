package com.mdq.auditinspectionapp.Interfaces;

public interface Interface_FinalInvoice {
    /**
     * @param invoice
     * @breif interface to pass the invoice
     */
    void FinalInvoiceCall(int invoice);
}
