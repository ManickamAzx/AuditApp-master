package com.mdq.auditinspectionapp.Pojo.JsonRequest;

import java.util.List;

public class GenerateUpdateInspectionRequestModel {


    public String inspectionDate;
    public String qcBy;
    public String result;
    public String qcRemarks;
    public String updateForm;
    public String pgmCode;
    public String sourceFlag;
    public int sourceId;
    public int styleId;
    public List<String> customerOrderNos;

}
