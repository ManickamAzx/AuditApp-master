package com.mdq.auditinspectionapp.Interfaces.ViewInterface;

public interface BrandRequestInterface {
    void generateBrandRequest();
}
