package com.mdq.auditinspectionapp.ViewModel;

public class SourceRequestBaseViewModel {

    private String Authorization;

    public String getAuthorization() {
        return Authorization;
    }

    public void setAuthorization(String authorization) {
        Authorization = authorization;
    }
}
