package com.mdq.auditinspectionapp.Pojo.JsonRequest;

public class GenerateSupplierRequestModel {

    public String sourceId;
    public String sourceFlag;
    public String seasonId;


}
